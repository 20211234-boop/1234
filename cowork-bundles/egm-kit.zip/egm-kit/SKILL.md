---
name: egm-kit
description: 구글 코끼리·금붕어 모델(EGM). 맥락을 아는 AI가 기획서·설계 문서를 쓰고, 이전 대화를 모르는 새 AI 리뷰어들이 백지 상태에서 허점을 찾는다. 사용자가 "egm 써줘", "egm으로", "egm 검토", "코끼리 금붕어", "금붕어 검토", "egm 초안", "egm 지적 반영"이라고 할 때 사용. "egm"이라는 말 없이 기획서·제안서 검토만 부탁하면 바로 실행하지 말고 "EGM으로 검토할까요? 한도를 많이 씁니다"라고 먼저 묻는다.
---

# egm-kit

여러 스킬을 하나로 묶은 안내판이다. 요청에 맞는 모드를 고르고, 그 모드의 `MODE.md`를 **끝까지 읽은 뒤 그대로 따른다.** (`MODE.md`는 원래 스킬의 SKILL.md를 이름만 바꾼 것이다.)

| 모드 | 언제 | 읽을 파일 |
|---|---|---|
| `egm-brainstorm` | 아이디어만 있을 때 "egm 써줘" — 질문으로 요구사항 정리 | `modes/egm-brainstorm/MODE.md` |
| `egm-draft` | "egm으로 기획서 써줘", "egm 초안" — 설계 문서를 섹션별로 작성 | `modes/egm-draft/MODE.md` |
| `egm-review` | 문서가 있을 때 "egm 써줘", "egm 검토" — 금붕어 리뷰어 5단계 검토 | `modes/egm-review/MODE.md` |
| `egm-resolve` | "egm 지적 반영해줘" — 리뷰 지적 사항 반영 | `modes/egm-resolve/MODE.md` |
| `egm-review-loop` | "지적 없을 때까지 egm" — 검토·수정 반복 | `modes/egm-review-loop/MODE.md` |
| `egm-bootstrap` | "egm으로 코드 문서화" — 기존 코드에서 README·설계 문서 만들기 | `modes/egm-bootstrap/MODE.md` |
| `egm-drift-report` | "egm으로 설계와 코드 비교" — 코드가 설계에서 벗어났는지 점검 | `modes/egm-drift-report/MODE.md` |

**순서:** 문서가 있는지 애매하면 한 줄로 묻는다. 순서: brainstorm → draft → review → resolve.

## 규칙

- 모드의 `MODE.md`가 가리키는 파일 경로(`references/`, `agents/`, `resources/`, `scripts/` 등)는 그 모드 폴더(`modes/<모드>/`) 기준이다.
- 맞는 모드가 둘 이상이면 표의 위쪽부터 쓴다. 맞는 모드가 없으면 이 묶음을 쓰지 않는다.
- 모드 이름으로 부르면(예: "/crash-out", "crash-out 써줘") 그 모드를 바로 쓴다.
- 어떤 모드를 쓰는지 첫 줄에 한 번만 짧게 알린다. 예: "crash-out 모드로 확인합니다."
