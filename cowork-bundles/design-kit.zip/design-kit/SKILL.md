---
name: design-kit
description: 보여줄 결과물 디자인 묶음. 해외 서비스 84곳의 디자인 시스템 적용(awesome-design), AI티 금지 목록과 자가 검사(aura-farming), 개성 있는 웹 디자인(frontend-design), 회사 웹사이트 제작(taste), 이미지·스크린샷을 웹페이지로(image-to-code), 웹 접근성·UI 점검(web-design-guidelines). "슬라이드", "PPT", "발표자료", "포스터", "OO 스타일로", "OO 느낌으로", "디자인 시스템", "웹페이지", "랜딩", "사이트", "이 이미지처럼", "스크린샷을 코드로", "UI 검토", "접근성 점검", "AI티 안 나게" 요청에 사용.
---

# design-kit

여러 스킬을 하나로 묶은 안내판이다. 요청에 맞는 모드를 고르고, 그 모드의 `MODE.md`를 **끝까지 읽은 뒤 그대로 따른다.** (`MODE.md`는 원래 스킬의 SKILL.md를 이름만 바꾼 것이다.)

| 모드 | 언제 | 읽을 파일 |
|---|---|---|
| `awesome-design` | "OO 스타일로", "디자인 시스템 골라줘", PPT·보고서·웹의 색과 서체를 정할 때 | `modes/awesome-design/MODE.md` |
| `aura-farming` | 슬라이드·포스터·광고·웹 같은 보여줄 결과물을 만들 때, 내보내기 전 AI티 검사 | `modes/aura-farming/MODE.md` |
| `frontend-design` | 웹페이지·화면을 새로 만들거나 고칠 때 (taste와 둘 중 하나만) | `modes/frontend-design/MODE.md` |
| `taste` | 회사·제품·가게 웹사이트를 본격적으로 만들 때 (frontend-design과 둘 중 하나만) | `modes/taste/MODE.md` |
| `image-to-code` | 스크린샷·시안 이미지를 웹페이지 코드로 만들 때 | `modes/image-to-code/MODE.md` |
| `web-design-guidelines` | 만든 웹페이지를 접근성·폼·애니메이션 규칙으로 점검할 때 | `modes/web-design-guidelines/MODE.md` |

**순서:** PPT·보고서: awesome-design → 제작 → aura-farming. 웹: awesome-design → frontend-design 또는 taste → web-design-guidelines.

## 규칙

- 모드의 `MODE.md`가 가리키는 파일 경로(`references/`, `agents/`, `resources/`, `scripts/` 등)는 그 모드 폴더(`modes/<모드>/`) 기준이다.
- 맞는 모드가 둘 이상이면 표의 위쪽부터 쓴다. 맞는 모드가 없으면 이 묶음을 쓰지 않는다.
- 모드 이름으로 부르면(예: "/crash-out", "crash-out 써줘") 그 모드를 바로 쓴다.
- 어떤 모드를 쓰는지 첫 줄에 한 번만 짧게 알린다. 예: "crash-out 모드로 확인합니다."
