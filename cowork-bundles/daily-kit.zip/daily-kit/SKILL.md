---
name: daily-kit
description: 매일 쓰는 업무 보조 묶음. 대화 정리·인수인계(handoff), 사용량 한도 절약(limit-saver), 숫자·법규·사실 검증(crash-out), AI티 나는 글 다듬기(humanizer), 답을 첫 줄에 쓰는 간결 모드(i-have-adhd), 초간결 답변(caveman). "정리해서 넘겨줘", "인수인계", "한도", "토큰 아껴", "맞는지 확인", "검증해줘", "사실 확인", "요율", "법 조항", "공지문 다듬어", "메일 자연스럽게", "AI티 없애", "짧게 답해", "/handoff", "/crash-out", "/humanizer", "/limit-saver", "/i-have-adhd", "/caveman" 요청에 사용.
---

# daily-kit

여러 스킬을 하나로 묶은 안내판이다. 요청에 맞는 모드를 고르고, 그 모드의 `MODE.md`를 **끝까지 읽은 뒤 그대로 따른다.** (`MODE.md`는 원래 스킬의 SKILL.md를 이름만 바꾼 것이다.)

| 모드 | 언제 | 읽을 파일 |
|---|---|---|
| `handoff` | 대화가 길어졌거나 "정리해서 넘겨줘", "인수인계"라고 할 때 | `modes/handoff/MODE.md` |
| `limit-saver` | "한도", "토큰 아껴", "사용량 아껴"라고 할 때 (켜면 대화 끝까지 유지) | `modes/limit-saver/MODE.md` |
| `crash-out` | 숫자·금액·요율·법 조항·사실을 확인할 때, "맞는지 확인", "검증"이라고 할 때 | `modes/crash-out/MODE.md` |
| `humanizer` | 공지문·메일·보고서 문장을 자연스럽게 다듬을 때, "AI티 없애"라고 할 때 | `modes/humanizer/MODE.md` |
| `i-have-adhd` | "/i-have-adhd" 또는 "답부터 짧게"라고 할 때 (켜면 "stop adhd mode"까지 유지) | `modes/i-have-adhd/MODE.md` |
| `caveman` | "/caveman", "초간결", "아주 짧게"라고 할 때. limit-saver·i-have-adhd와 동시에 켜지 않는다 | `modes/caveman/MODE.md` |

## 규칙

- 모드의 `MODE.md`가 가리키는 파일 경로(`references/`, `agents/`, `resources/`, `scripts/` 등)는 그 모드 폴더(`modes/<모드>/`) 기준이다.
- 맞는 모드가 둘 이상이면 표의 위쪽부터 쓴다. 맞는 모드가 없으면 이 묶음을 쓰지 않는다.
- 모드 이름으로 부르면(예: "/crash-out", "crash-out 써줘") 그 모드를 바로 쓴다.
- 어떤 모드를 쓰는지 첫 줄에 한 번만 짧게 알린다. 예: "crash-out 모드로 확인합니다."
