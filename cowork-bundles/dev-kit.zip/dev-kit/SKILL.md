---
name: dev-kit
description: 프로그램·코드 작업 묶음. 구현 계획(ecc-plan), 코드 리뷰(ecc-code-review), 빌드 에러 수정(ecc-build-fix), 테스트 보강(ecc-test-coverage), 과한 코드 막는 원칙(karpathy-guidelines), 메타 Astryx 디자인 시스템으로 React 웹앱 만들기(astryx), 브라우저 자동화(agent-browser). "계획 세워줘", "코드 리뷰", "빌드 에러", "테스트 추가", "커버리지", "스크립트 짜줘", "매크로", "사내 웹앱", "관리자 대시보드", "Astryx", "브라우저로 확인" 요청에 사용.
---

# dev-kit

여러 스킬을 하나로 묶은 안내판이다. 요청에 맞는 모드를 고르고, 그 모드의 `MODE.md`를 **끝까지 읽은 뒤 그대로 따른다.** (`MODE.md`는 원래 스킬의 SKILL.md를 이름만 바꾼 것이다.)

| 모드 | 언제 | 읽을 파일 |
|---|---|---|
| `karpathy-guidelines` | 코드·스크립트·매크로를 쓰거나 고칠 때 항상 (가정 먼저 밝히기, 최소 코드) | `modes/karpathy-guidelines/MODE.md` |
| `ecc-plan` | 기능을 새로 만들기 전 "계획 세워줘" — 확인받기 전에는 코드를 쓰지 않는다 | `modes/ecc-plan/MODE.md` |
| `ecc-code-review` | "코드 리뷰", "검토해줘" — 보안·품질 점검 (GitHub 게시는 요청할 때만) | `modes/ecc-code-review/MODE.md` |
| `ecc-build-fix` | "빌드 에러", "빌드가 안 돼" — 에러를 하나씩 최소 수정 | `modes/ecc-build-fix/MODE.md` |
| `ecc-test-coverage` | "테스트 추가", "커버리지" — 80% 미만 파일에 테스트 보강 | `modes/ecc-test-coverage/MODE.md` |
| `astryx` | "Astryx"라고 하거나 React로 사내 웹앱·대시보드를 만들 때 (astryx 프로그램 설치 필요) | `modes/astryx/MODE.md` |
| `agent-browser` | "agent-browser"라고 하거나 그 프로그램이 설치된 컴퓨터에서 브라우저 확인이 필요할 때 | `modes/agent-browser/MODE.md` |

## 규칙

- 모드의 `MODE.md`가 가리키는 파일 경로(`references/`, `agents/`, `resources/`, `scripts/` 등)는 그 모드 폴더(`modes/<모드>/`) 기준이다.
- 맞는 모드가 둘 이상이면 표의 위쪽부터 쓴다. 맞는 모드가 없으면 이 묶음을 쓰지 않는다.
- 모드 이름으로 부르면(예: "/crash-out", "crash-out 써줘") 그 모드를 바로 쓴다.
- 어떤 모드를 쓰는지 첫 줄에 한 번만 짧게 알린다. 예: "crash-out 모드로 확인합니다."
